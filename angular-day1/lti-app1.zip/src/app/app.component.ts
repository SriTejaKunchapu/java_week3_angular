import { Component } from '@angular/core';

//metadata 
@Component({
  selector: 'app-root', 
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'] 
})

//model 
export class AppComponent {
  title = 'LTI-Fullstack++ trianing ';
}
